// ==========================================
// GLOBAL VARIABLES AND AUXILIARY FUNCTIONS (WASM)
// ==========================================

const defaultMessageHandler = function (msg, level) {
    switch (level) {
        case 100:
        case 200:
            break;
        case 300:
            break;
        default:
            if (typeof Module !== 'undefined' && Module._free) {
                Module._free();
            }
            break;
    }
};

let fileStatus = {
    segment: false,
    transition: false,
    reset: function () {
        this.segment = false;
        this.transition = false;
    },
    isDone: function() {
        return this.segment !== false && this.transition !== false;
    }
};

var res;
var maxPrecision = 6;
let vueAppInstance = null; // Internal reference to Vue



function initFileForWasm(fileInput, targetName, callback) {
    const FILEPATH = '/';
    if (!fileInput || fileInput.files.length == 0) {
        return;
    }

    let file = fileInput.files[0];
    let fr = new FileReader();
    fr.onload = function () {
        let data = new Uint8Array(fr.result);
        
        // --- JAVÍTÁS 1: A pontos elérési út kezelése (dupla perjel elkerülése) ---
        let fullPath = FILEPATH + targetName; // Ha FILEPATH = '/', akkor ez '/segment' vagy '/transition'
        
        // --- JAVÍTÁS 2: Erőteljesebb Emscripten FS tisztítás ---
        try {
            let stat = FS.analyzePath(fullPath);
            if (stat.exists) {
                FS.unlink(fullPath);
                console.log("Sikeresen unlinked a WASM FS-ből:", fullPath);
            }
        } catch(e) {
            // Ha még nem létezik, az analyzePath hibát dobhat, ezt csendben elkapjuk
        }
        
        // Létrehozzuk a friss fájlt a virtuális lemezen
        FS.createDataFile(FILEPATH, targetName, data, true, true, true);
        
        // Visszaadjuk a sikeres callback-et a pontos elérési úttal
        callback(file, fullPath);
    };
    fr.readAsArrayBuffer(file);
}

function doStart(nqn, dobootstrap, botiter, unc, minSize) {
	
	window.downloadedFilesList = [];
    if (typeof vueAppInstance !== 'undefined' && vueAppInstance) {
        vueAppInstance.$forceUpdate();
    }
	
    if (fileStatus.isDone()) {
        if (vueAppInstance) {
            vueAppInstance.log('WASM engine calculation starts...', 'SYSTEM', '#33ff33');
        }
        
        setTimeout(() => {
            try {
                // Átadjuk az összes régi és új (unc, minSize) paramétert a C++ felé
                res = Module.processInputFile(
                    fileStatus.segment.target,
                    fileStatus.segment.original.name,
                    fileStatus.transition.target,
                    fileStatus.transition.original.name,
                    dobootstrap,
                    botiter,
                    nqn,
                    unc,       
                    minSize    
                );
                
                Module.runMARVEL();
                
                // Intelligens belső hibaellenőrzés
                let errorMessage = Module.getResultStorage().getErrorMessage();
                
                if (errorMessage && errorMessage.trim() !== "") {
                    if (vueAppInstance) {
                        let cleanError = errorMessage.replace(/<br\s*\/?>/gi, ' ');
                        vueAppInstance.log(`MARVEL Engine error: ${cleanError}`, 'ERROR', '#d9534f');
                        vueAppInstance.isRunning = false;
                        vueAppInstance.showRerunButton = true;
                    }
                    $("#ofiles").css('display', 'none');
                    return; // Megállítjuk a folyamatot, nem fut le a "SUCCESS"
                }
                
                postProcess();
                
                if (vueAppInstance) {
                    vueAppInstance.log('The calculation was successful!', 'SUCCESS', '#33ff33');
                    vueAppInstance.isRunning = false;
                    vueAppInstance.showRerunButton = true;
                }
            } catch (err) {
                if (vueAppInstance) {
                    vueAppInstance.log(`WASM Runtime Error: ${err.message}`, 'ERROR', '#d9534f');
                    vueAppInstance.isRunning = false;
                    vueAppInstance.showRerunButton = true;
                }
            }
        }, 100);
    } else {
        if (vueAppInstance) {
            vueAppInstance.log('Waiting for the other file to load...', 'INFO', '#00ffff');
        }
    }
}

// ==========================================
// JQUERY EVENT HANDLERS FOR THE BAD LINES TABLE
// ==========================================

$(document).on('click', '.incunc', function(){
    // 1. Kiszedjük a referenciát és a kiszámolt optimális bizonytalanságot közvetlenül a HTML sorból!
    var actRef = $(this).attr("ref").trim();	
    
    // Megkeressük a gombhoz tartozó sorban a harmadik oszlop (Opt. unc.) tartalmát
    var row = $(this).closest('tr');
    var optUncText = row.find('td:nth-child(3)').text().trim(); // Pl: "1.230e-03"
    var optUncVal = parseFloat(optUncText);

    if (isNaN(optUncVal)) {
        console.error("Nem sikerült beolvasni az optimális bizonytalanságot a HTML-ből!");
        return;
    }

    // Vizuális visszajelzés a felületen
    row.css("background-color","#dff0d8");
    $(this).remove();
    
    // 2. --- SZÖVEG ALAPÚ FÁJLFRISSÍTÉS (TELJESEN C++ MENTESEN) ---
    try {
        if (fileStatus.transition && fileStatus.transition.target) {
            let targetFile = fileStatus.transition.target;
            
            // Beolvassuk a virtuális fájl tartalmát
            let currentContentUint8 = FS.readFile(targetFile);
            let currentText = new TextDecoder("utf-8").decode(currentContentUint8);
            
            let lines = currentText.split('\n');
            let updatedLines = [];
            let newUncStr = optUncVal.toExponential(6);
            
            for (let line of lines) {
                let trimmed = line.trim();
                if (trimmed === "" || trimmed.startsWith("&")) {
                    updatedLines.push(line);
                    continue;
                }
                
                // Ha a sor végén ott van a keresett referenciánk (actRef)
                if (trimmed.endsWith(actRef)) {
                    let tokens = trimmed.split(/\s+/);
                    let uncSelectValue = parseInt(document.getElementById('uncSelect').value) || 1;
                    
                    if (uncSelectValue === 1 && tokens.length >= 3) {
                        // UNC 1: 2. oszlop (index 1) a bizonytalanság
                        tokens[1] = newUncStr;
                    } else if (uncSelectValue === 2 && tokens.length >= 4) {
                        // UNC 2: 3. oszlop (index 2) a bizonytalanság
                        tokens[2] = newUncStr;
                    }
                    
                    updatedLines.push(tokens.join(" "));
                } else {
                    updatedLines.push(line);
                }
            }
            
            // Elmentjük a virtuális fájlrendszerbe
            let newText = updatedLines.join("\n");
            FS.writeFile(targetFile, newText);
            console.log("WASM FS fájl SIKERESEN frissítve (100% kliensoldali HTML-ből):", targetFile);
        }
    } catch(err) {
        console.error("Hiba a WASM FS fájl mentése közben:", err);
    }
    
    if (vueAppInstance) {
        vueAppInstance.showRerunButton = true;
        vueAppInstance.log(`Uncertainty increased and file safely auto-saved: ${actRef}`, 'WARN', '#f0ad4e');
    }
});

$(document).on('click', '.delete', function(){
    var actRef = $(this).attr("ref").trim();	
    var nbBTr = Module.getResultStorage().getBadlines().size();
    for(var i=0; i < nbBTr; i++) {
        var bref = Module.getResultStorage().getBadlines().get(i).getRef().trim();
        if(actRef == bref) {
            // Module.getResultStorage().getBadlines().get(i).delTr();
        }
    }

    $(this).parent().parent().css("background-color","#dff0d8");
    $(this).remove();
    
    if (vueAppInstance) {
        vueAppInstance.showRerunButton = true;
        vueAppInstance.log(`Row marked for deletion: ${actRef}`, 'WARN', '#f0ad4e');
    }
});

// ==========================================
//DOWNLOAD, VIEW AND EXPORT FILE
// ==========================================

function downloadFile(path, mime) {
    mime = mime || "plain/text";
    let content = Module.FS.readFile(path);
 
    var a = document.createElement('a');
    a.download = path.split('\\').pop().split('/').pop();
    a.href = URL.createObjectURL(new Blob([content], {type: mime}));
    a.style.display = 'none';

    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
        URL.revokeObjectURL(a.href);
        document.body.removeChild(a);
    }, 2000);
}

function openNewTab(path, mime) {
   mime = mime || "plain/text";	
   let content = Module.FS.readFile(path);	
   const blb = new Blob([content], {type: "text/plain"});
   const reader = new FileReader();
   
   reader.addEventListener('loadend', (e) => {
      const text = e.srcElement.result;
      var myWindow = window.open("", '_blank');
      
      // SECURITY CHECK: If your browser has blocked the pop-up window
      if (!myWindow) {
          alert("Your browser has blocked pop-ups! Please allow pop-ups to view this page.");
          return;
      }
      
      let textToWrite = text.replace(/\n/g, "<br/>");
      myWindow.document.writeln(textToWrite);
      setTimeout(() => window.URL.revokeObjectURL(text), 100);
   });

   reader.readAsText(blb);
}
function download(data, filename, type) {
    var a = document.createElement("a"),
        file = new Blob([data], { type: type });
    if (window.navigator.msSaveOrOpenBlob) {
        window.navigator.msSaveOrOpenBlob(file, filename);
    } else {
        var url = URL.createObjectURL(file);
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        setTimeout(function () {
            document.body.removeChild(a);
            window.URL.revokeObjectURL(url);
        }, 0);
    }
}

function downloadNewTrans() {
    var vtext = "";
    var nbBTr = Module.getResultStorage().getTransitions().size();
    var unit = "";
    var unc = 0.0;

    for(var i=0; i < Module.getResultStorage().getDeletedLines().size(); i++) {
        vtext += Module.getResultStorage().getDeletedLines().get(i).getFreq() + " " +
                 Module.getResultStorage().getDeletedLines().get(i).getUnc() + " " +
                 Module.getResultStorage().getDeletedLines().get(i).getUnc() + " " +
                 Module.getResultStorage().getDeletedLines().get(i).getAssu() + " " +
                 Module.getResultStorage().getDeletedLines().get(i).getAssl() + " " +
                 Module.getResultStorage().getDeletedLines().get(i).getRef() + "\n";
    }
    
    for(var i=0; i < nbBTr; i++) {
        unit = Module.getResultStorage().getTransitions().get(i).getUnit();
        // Retrieve the uncertainty from the corresponding WASM transient object
        let actualUnc = Module.getResultStorage().getTransitions().get(i).getUnc();
        unc = actualUnc;
        
        if(unit == "Hz") {
            unc = actualUnc * 2.99792458E10;
        }
        if(unit == "kHz") {
            unc = actualUnc * 2.99792458E10 / 1E3;
        }
        if(unit == "MHz") {
            unc = actualUnc * 2.99792458E10 / 1E6;
        }
        if(unit == "GHz") {
            unc = actualUnc * 2.99792458E10 / 1E9;
        }
        if(unit == "THz") {
            unc = actualUnc * 2.99792458E10 / 1E12;
        }
        
        vtext += Module.getResultStorage().getTransitions().get(i).getOfreq() + " "
                + Module.getResultStorage().getTransitions().get(i).getUncorig() + " " + unc.toExponential(3) + " "
                + Module.getResultStorage().getTransitions().get(i).getNode1().getId() + " "
                + Module.getResultStorage().getTransitions().get(i).getNode2().getId() + " "
                + Module.getResultStorage().getTransitions().get(i).getRef() + "\n";
    }
    
    var d = new Date();
    var filename = "transitions_" + d.getDate() + "_" + (d.getMonth()+1) + "_" + d.getFullYear() + "_" + d.getHours() + "_" + d.getMinutes() + ".txt";
    download(vtext, filename, "text/plain;charset=utf-8");
}

function reset() {
    fileStatus.reset();
    document.getElementById('output').innerHTML = 'Loading...';
}

// ==========================================
//LAUNCHING AND CONFIGURING THE VUE 3 APPLICATION
// ==========================================

window.downloadedFilesList = [];

document.addEventListener('DOMContentLoaded', () => {
    const { createApp } = Vue;


    try {
        const app = createApp({
            data() {
                return {
                    nqn: 6,
                    runBootstrap: false,
                    botiter: 100,
                    isRunning: false,
                    showRerunButton: false,
                    logs: [],
                    outputFiles: []
                }
            },
            mounted() {
                // We save the Vue instance reference for external functions
                vueAppInstance = this;
                
                this.log('MARVEL 4.1 offline engine successfully loaded.', 'SYSTEM', '#33ff33');
                this.log('Please select the Segment and Transition files to start.', 'INFO', '#00ffff');
            },
            methods: {
                log(text, type = 'INFO', color = '#00ff00') {
                    const time = new Date().toLocaleTimeString();
                    this.logs.push({ time, type, text, color });
                    setTimeout(() => {
                        const consoleBox = document.getElementById('logConsole');
                        if (consoleBox) consoleBox.scrollTop = consoleBox.scrollHeight;
                    }, 40);
                },
                
				runMarvel() {
					this.isRunning = true;
					this.showRerunButton = false;
					this.outputFiles = [];
					
					// Korábbi táblázatok és hibaüzenetek ürítése
					$("#eltext, #els, #btext, #btrs, #bnote").html("");
					
					// A fájl státuszok teljes tisztítása (így megvárják egymást!)
					if (typeof fileStatus !== 'undefined' && fileStatus.reset) {
						fileStatus.reset();
					}
					fileStatus.segment = { original: null, target: null };
					fileStatus.transition = { original: null, target: null };
					
					this.log('Processing new files...', 'START', '#ffff00');
					
					let dobootstrap = this.runBootstrap ? 1 : 0;
					let uncValue = parseInt(document.getElementById('uncSelect').value) || 1;
					let minSizeValue = 1;
					
					// Segment fájl betöltése
					initFileForWasm(document.getElementById('segmentFile'), 'segment', (originalFile, targetPath) => {
						fileStatus.segment = { original: originalFile, target: targetPath };
						this.log(`Segment file loaded into the WASM file system: ${originalFile.name}`, 'FS', '#00ffaa');
						
						if (fileStatus.transition.target) {
							doStart(this.nqn, dobootstrap, this.botiter, uncValue, minSizeValue);
						}
					});
					
					// Transition fájl betöltése
					initFileForWasm(document.getElementById('transitionFile'), 'transition', (originalFile, targetPath) => {
						fileStatus.transition = { original: originalFile, target: targetPath };
						this.log(`Transition file loaded into the WASM file system: ${originalFile.name}`, 'FS', '#00ffaa');
						
						if (fileStatus.segment.target) {
							doStart(this.nqn, dobootstrap, this.botiter, uncValue, minSizeValue);
						}
					});
				},
				
	
               rerunMarvel() {
					this.isRunning = true;
					this.showRerunButton = false;
					this.log('Rerun MARVEL on the modified data matrix...', 'RERUN', '#ffaa00');
					
					setTimeout(() => {
						try {
							let dobootstrap = this.runBootstrap ? 1 : 0;
							let uncValue = parseInt(document.getElementById('uncSelect').value) || 1;
							let minSizeValue = 1;

							// Elindítjuk a C++ számolást (a doStart-on belüli setTimeout miatt aszinkron!)
							doStart(this.nqn, dobootstrap, this.botiter, uncValue, minSizeValue);
							
						} catch (err) {
							this.log(`Error while rerunning: ${err.message}`, 'ERROR', '#d9534f');
							this.isRunning = false; // Csak hiba esetén lőjük le itt!
							this.showRerunButton = true;
						}
						// NINCS ISRUNNING = FALSE A FINALLY-BAN! Az overlay aktív marad!
					}, 50);
				}, // itt zártuk le a rerunMarvel-t vesszővel!
				
				triggerDownload(file) {
					downloadFile(file); // Eredeti letöltés meghívása

					// ÚJ: hozzáadjuk a globális tömbhöz a fájlt, ha még nincs benne
					if (window.downloadedFilesList && !window.downloadedFilesList.includes(file)) {
						window.downloadedFilesList.push(file);
					}
					
					// Frissítjük a Vue-t, hogy azonnal át fessen a gomb
					this.$forceUpdate(); 
				},
				isDownloaded(file) {
					if (window.downloadedFilesList) {
						return window.downloadedFilesList.includes(file);
					}
					return false;
				},
				triggerView(file) {
					openNewTab(file);
				},
				triggerNewTransDownload() {
					downloadNewTrans();
				}
			} // <-- Ez zárja le a Vue methods: { blokkját
			});
        // Vue globális hiba elkapása
        app.config.errorHandler = (err, vm, info) => {
            console.error("VUE INTERNAL ERROR:", err, info);
        };

        window.vueApp = app.mount('#app');
        console.log("Vue successfully attempted to load into #app!");

    } catch (vueError) {
        console.error("Critical error when starting Vue:", vueError);
    }
});

// ==========================================
// POST-TREATMENT OF RESULTS
// ==========================================
function postProcess() {
    // Ha végzett a számolás, itt állítjuk le a Vue isRunning állapotát!
    if (vueAppInstance) {
        vueAppInstance.isRunning = false;
        vueAppInstance.showRerunButton = true;
    }

    let container = document.getElementById('output');

    let errorMessage = Module.getResultStorage().getErrorMessage();
    $("#errorM").html("");
    if (errorMessage != "") {
        let econtent = "<div class='alert alert-danger' role='alert'>" + errorMessage + "</div><br/>";
        $("#errorM").html(econtent);
        if (vueAppInstance) {
            vueAppInstance.log(`MARVEL Engine error message: ${errorMessage}`, "ERROR", "#d9534f");
        }
    }
    
    let files = Module.getResultStorage().getOutputFiles();
    
    // Let's also populate the Vue array with the files so your pretty buttons can appear!
    if (vueAppInstance) {
        let tempFiles = [];
        for (let i = 0; i < files.size(); i++) {
            tempFiles.push(files.get(i));
        }
        vueAppInstance.outputFiles = tempFiles;
    }

    // We only write to the output if it exists
    if (container) {
        container.innerHTML = '';
        let content = '';
        for (let i = 0; i < files.size(); i++) {
            content += '<li>' + files.get(i) + ': <a href="javascript: downloadFile(\'' + files.get(i) + '\')">Download</a> or <a href="javascript: openNewTab(\'' + files.get(i) + '\')"> View in browser</a></li>';
        }
        content += '<li>New Transitions file: <a href="javascript: downloadNewTrans()">Download</a></li>';
        container.innerHTML = '<ul>' + content + '</ul>';
    }

    $("#ofiles").css('display', 'block');
    
    // --- Energies 
    var nbEl = Module.getResultStorage().getEnergies().size();
    var eltext = "<h3>MARVEL Energies</h3><p>Table below contains only the first 100 energy levels. To see all energy levels download the EnergyLevels.txt file.</p>";
    $("#eltext").html(eltext);

    var ELTable = "<table id='restable' class='table table-striped' ><thead><tr><th>Assignments</th><th>Energy value / cm-1</th><th>Unc / cm-1</th></thead><tbody>";
    var countEL = 1;
    for (var i = 0; i < nbEl; i++) {
        if (parseFloat(Module.getResultStorage().getEnergies().get(i).getEnergy()) >= 0.0) {
            ELTable += "<tr><td>" + Module.getResultStorage().getEnergies().get(i).getId() + " </td><td>" +
                    parseFloat(Module.getResultStorage().getEnergies().get(i).getEnergy()).toFixed(maxPrecision) + " </td><td>" +
                    parseFloat(Module.getResultStorage().getEnergies().get(i).getUncFinal()).toFixed(maxPrecision) + "</td></tr>";
            countEL++;
        }
        if (countEL > 100) break;
    }

    ELTable += "</tbody></table>";
    $("#els").html(ELTable);
    
    // 2. SAFETY CHECK: Only format as Datatable if the table actually exists in the DOM
    if ($('#restable').length) {
        $('#restable').DataTable({ "order": [[ 1, "asc" ]] });
    }

    // --- Bad lines (CSOPORTOS KIJELÖLÉSSEL ÉS CHECKBOXOKKAL) ---
    var nbBTr = Module.getResultStorage().getBadlines().size();
    console.log("nbBTR= " + nbBTr);
    
    var prnbTR = Math.min(100, nbBTr);
    var btext = "Table below contains only the first worst 100 bad lines. To see the details of bad lines, please check the BadLines.txt file." +
      " Click on the 'Inc. Unc.' button to increase the uncertainty of the line to the optimal value. After increasing one or more uncertainties, you can run the MARVEL again.</p>";
    $("#btext").html(btext);

    // Kék csoportos gomb a fejlécbe (pici belső margóval, hogy elférjen)
    var bulkActionButton = '<button type="button" id="btn-bulk-inc" class="btn btn-primary btn-sm fw-bold py-1 px-2"><span class="glyphicon glyphicon-arrow-up"></span> Inc. Selected</button>';

    // Táblázat fejléc: Fix szélességek helyett flexibilis, de szabályozott elrendezés
    var badlinestext = 
        "<table id='blines' class='table table-striped' style='width: 100%;'>" + 
        "<thead>" +
        "<tr>" +
        // Ide illeszd be a checkboxot az első th-ba:
        "<th style='text-align: center;'><input type='checkbox' id='select-all-bad'></th>" + 
        "<th>Line tag</th>" +
        "<th>Orig. unc.</th>" +
        "<th>Opt. unc.</th>" +
        "<th>Ratio</th>" +
        "<th style='text-align: center;'>" + bulkActionButton + "</th>" + 
        "</tr>" +
        "</thead>" +
        "<tbody>";

    var ref = "";
    var unc, optunc;
    var style = "";    
    var deleteable = 0;
    
    for (var i = 0; i < prnbTR; i++) {
        ref = Module.getResultStorage().getBadlines().get(i).getRef().trim();
        unc = Module.getResultStorage().getBadlines().get(i).getOunc();
        optunc = 1.01 * Module.getResultStorage().getBadlines().get(i).getMunc();

        style = "";
        if (optunc / unc > 100) {
            style = "style= 'background-color: #ea8992'";
            deleteable = 1;
        }

        // Egyedi gomb
        var incbutton = '<button type="button" class="btn btn-primary btn-sm incunc py-1 px-2" ref="' + ref + '"><span class="glyphicon glyphicon-arrow-up"></span> Inc. unc.</button>';
        
        // A soroknál pedig a gomb celláját szintén 120px-re állítjuk:
		badlinestext += "<tr " + style + ">" + 
			"<td style='text-align: center; padding: 6px 4px;'><input type='checkbox' class='bad-checkbox' value='" + ref + "'></td>" + 
			"<td>" + ref + "</td>" +
			"<td>" + parseFloat(unc).toExponential(3) + "</td>" +
			"<td>" + parseFloat(optunc).toExponential(3) + "</td>" +
			"<td>" + parseFloat(optunc / unc).toFixed(5) + "</td>" +
			"<td style='text-align: center;'>" + incbutton + "</td>" + 
			"</tr>";
    }

    badlinestext += "</tbody></table>";
	
    $("#bnote").html("");
    if (deleteable == 1) {
        var bnote = '<div class="alert alert-danger" role="alert">The database contains transitions with extremly large optimal uncertainty (see the red row(s) in the Table below). These transitions must be deleted or reassigned in your database by hand.</div>';
        $("#bnote").html(bnote);
    }
    
    $("#btrs").html(badlinestext);
    
    // 3. SAFETY CHECK: Format only if it exists
    if ($('#blines').length) {
    var table = $('#blines').DataTable({ 
        "autoWidth": false, // <--- Ez tiltja le a DataTables okoskodását
        "order": [[ 4, "desc" ]],
        "columnDefs": [
            { "orderable": false, "targets": [0, 5] },
            { "width": "40px", "targets": 0 },        // Checkbox oszlop szélessége
            { "width": "140px", "targets": 5 }       // A gomb oszlop szélessége
        ]
    });

        // "Select All" Checkbox működtetése
        $('#select-all-bad').on('click', function() {
            // A DataTables-en belüli összes checkboxot kijelöljük/kivesszük, nem csak a látható oldalon lévőket
            var rows = table.rows({ 'search': 'applied' }).nodes();
            $('input[type="checkbox"]', rows).prop('checked', this.checked);
        });

        // Ha manuálisan kivesznek egy checkboxot, a "Select All" is változzon meg
        $('#blines tbody').on('change', 'input[type="checkbox"]', function() {
            if (!this.checked) {
                var el = $('#select-all-bad').get(0);
                if (el && el.checked && ('indeterminate' in el)) {
                    el.indeterminate = true;
                }
            }
        });

        // Csoportos "Inc. unc. on Selected" gomb eseménykezelése
        $('#btn-bulk-inc').on('click', function() {
            var selectedRefs = [];
            
            // Összegyűjtjük a kijelölt checkboxok értékeit (a Line tag-eket)
            table.$('input[type="checkbox"]:checked').each(function() {
                selectedRefs.push($(this).val());
            });

            if (selectedRefs.length === 0) {
                alert("Please select at least one transition first!");
                return;
            }

            if (confirm("Are you sure you want to increase uncertainty for the " + selectedRefs.length + " selected transitions?")) {
                // Végigmegyünk a kijelölteken, és mindegyikre "rákattintunk" a háttérben
                selectedRefs.forEach(function(ref) {
                    // Megkeressük az adott ref-hez tartozó egyedi gombot és meghívjuk a kattintás eseményét
                    $('button.incunc[ref="' + ref + '"]').click();
                });
                
                alert("Uncertainty successfully increased for selected transitions!");
            }
        });
    }
}