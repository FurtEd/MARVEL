========================================================================
                  MARVEL 4.1 Offline - User Guide
========================================================================

Welcome to the offline version of MARVEL 4.1! This tool runs directly in
your web browser without requiring an internet connection or installation.

------------------------------------------------------------------------
⚠️  CRITICAL FIRST STEP (DO NOT SKIP)
------------------------------------------------------------------------
You MUST extract (unzip) this folder before using the application.
Running the application directly from inside the ZIP file WILL cause it
to fail.

How to extract:
1. Right-click on the ZIP file.
2. Select "Extract All..." (or your local system's extraction tool).
3. Choose a destination folder on your computer and extract the files.

------------------------------------------------------------------------
🚀 HOW TO START THE APPLICATION
------------------------------------------------------------------------
1. Open the newly extracted folder.
2. Double-click on the "index.html" file.
3. The program will immediately open in your default web browser.
4. Upload your files and start calculating!

------------------------------------------------------------------------
🛑 IMPORTANT RULES (To keep the application working)
------------------------------------------------------------------------
* DO NOT change the folder structure. 
  The "index.html" file relies on the "build", "css", and "js" folders 
  being in the exact same location.
  
* DO NOT move the "index.html" file out of this folder. 
  It must stay right next to the other folders to load the MARVEL engine 
  properly.

* DO NOT rename any folders or files within this package.

------------------------------------------------------------------------
🔔 GET NOTIFIED ABOUT NEW VERSONS & NEED HELP?
------------------------------------------------------------------------
* To get email notifications when a new version is released:
  Go to our GitHub repository, click the "Watch" button in the top right
  corner, and select "Releases".

* To report bugs, ask questions, or request features:
  Please open a new ticket under the "Issues" tab on our GitHub page.
========================================================================